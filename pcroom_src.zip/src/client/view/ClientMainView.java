package client.view;

import javax.swing.JPanel;

public class ClientMainView extends JPanel {
	

}
